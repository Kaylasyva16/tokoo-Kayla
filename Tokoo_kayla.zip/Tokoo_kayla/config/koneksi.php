<?php
$koneksi = mysqli_connect("localhost", "root", "", "Tokoo_kayla");
if (!$koneksi) {
  die("Koneksi gagal: " . mysqli_connect_error());
}
?>
