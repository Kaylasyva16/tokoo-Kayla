<?php include 'config/koneksi.php'; ?>
<div id="transaksi" class="section d-none">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center">
      <i class="bi bi-receipt text-primary fs-4 me-2"></i>
      <h4 class="fw-bold text-primary mb-0">Data Transaksi</h4>
    </div>
    <button class="btn btn-primary px-3 rounded-pill" data-bs-toggle="modal" data-bs-target="#modalTambahTransaksi">
      <i class="bi bi-plus-circle"></i> Tambah
    </button>
  </div>

  <div class="card p-4 shadow-sm border-0 rounded-4">
    <div class="d-flex justify-content-end mb-3">
      <div id="exportButtons" class="d-flex"></div>
    </div>

    <div class="table-responsive">
      <table id="tabel-transaksi" class="table align-middle">
        <thead class="bg-light">
          <tr class="text-secondary fw-semibold align-middle" style="background-color:#f8f9fb;">
            <th>ID Transaksi</th>
            <th>Nama Pembeli</th>
            <th>Barang</th>
            <th>Jumlah</th>
            <th>Total Harga</th>
            <th>Tanggal</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $data = mysqli_query($koneksi, "
            SELECT t.*, p.nama_pembeli, b.nama_barang, b.harga
            FROM transaksi t
            JOIN pembeli p ON t.id_pembeli = p.id_pembeli
            JOIN barang b ON t.id_barang = b.id_barang
            ORDER BY t.id_transaksi ASC
          ");
          while($t = mysqli_fetch_array($data)) { ?>
          <tr style="border-bottom:1px solid #f0f0f0;">
            <td><?= $t['id_transaksi'] ?></td>
            <td class="fw-semibold"><?= $t['nama_pembeli'] ?></td>
            <td><?= $t['nama_barang'] ?></td>
            <td><?= $t['jumlah'] ?></td>
            <td>Rp<?= number_format($t['total_harga'], 0, ',', '.') ?></td>
            <td><?= $t['tanggal'] ?></td>
            <td>
              <button class="btn btn-sm btn-outline-primary me-1" 
                data-bs-toggle="modal" 
                data-bs-target="#editTransaksi<?= $t['id_transaksi'] ?>">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger" 
                onclick="hapusData('transaksi','<?= $t['id_transaksi'] ?>')">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>

          <!-- Modal Edit Transaksi -->
          <div class="modal fade" id="editTransaksi<?= $t['id_transaksi'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content border-0 rounded-4 shadow-sm">
                <div class="modal-header border-0">
                  <h5 class="fw-semibold text-primary mb-0">Edit Transaksi</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="proses.php" method="POST">
                  <div class="modal-body">
                    <input type="hidden" name="id_transaksi" value="<?= $t['id_transaksi'] ?>">

                    <div class="mb-3">
                      <label class="form-label">Nama Pembeli</label>
                      <select name="id_pembeli" class="form-select" required>
                        <?php
                        $pembeli = mysqli_query($koneksi, "SELECT * FROM pembeli ORDER BY nama_pembeli ASC");
                        while($p = mysqli_fetch_array($pembeli)) {
                          $selected = ($p['id_pembeli'] == $t['id_pembeli']) ? 'selected' : '';
                          echo "<option value='$p[id_pembeli]' $selected>$p[nama_pembeli]</option>";
                        }
                        ?>
                      </select>
                    </div>

                    <div class="mb-3">
                      <label class="form-label">Barang</label>
                      <select name="id_barang" class="form-select" required>
                        <?php
                        $barang = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY nama_barang ASC");
                        while($b = mysqli_fetch_array($barang)) {
                          $selected = ($b['id_barang'] == $t['id_barang']) ? 'selected' : '';
                          echo "<option value='$b[id_barang]' $selected>$b[nama_barang]</option>";
                        }
                        ?>
                      </select>
                    </div>

                    <div class="mb-3">
                      <label class="form-label">Jumlah</label>
                      <input type="number" name="jumlah" class="form-control" value="<?= $t['jumlah'] ?>" required>
                    </div>

                    <div class="mb-3">
                      <label class="form-label">Total Harga</label>
                      <input type="number" name="total_harga" class="form-control" value="<?= $t['total_harga'] ?>" required>
                    </div>
                  </div>

                  <div class="modal-footer border-0">
                    <button type="submit" name="edit_transaksi" class="btn btn-primary w-100 rounded-pill">Simpan Perubahan</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php } ?> 
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Transaksi -->
<div class="modal fade" id="modalTambahTransaksi" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 rounded-4 shadow-sm">
      <div class="modal-header border-0">
        <h5 class="fw-semibold text-primary mb-0">Tambah Transaksi Baru</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <?php
      $auto_tr = mysqli_query($koneksi, "SELECT id_transaksi FROM transaksi ORDER BY id_transaksi DESC LIMIT 1");
      $data_tr = mysqli_fetch_assoc($auto_tr);
      $kode_tr = isset($data_tr['id_transaksi']) ? $data_tr['id_transaksi'] : 'TR000';
      $urutan_tr = (int) substr($kode_tr, 2, 3);
      $urutan_tr++;
      $id_baru_tr = "TR" . str_pad($urutan_tr, 3, "0", STR_PAD_LEFT);
      $tanggal_hari_ini = date('Y-m-d');
      ?>

      <form action="proses.php" method="POST" id="formTransaksi">
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">ID Transaksi</label>
            <input type="text" name="id_transaksi" class="form-control" value="<?= $id_baru_tr ?>" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label">Pilih Pembeli</label>
            <select name="id_pembeli" class="form-select" required>
              <option value="">-- Pilih Pembeli --</option>
              <?php
              $pembeli = mysqli_query($koneksi, "SELECT * FROM pembeli ORDER BY nama_pembeli ASC");
              while($p = mysqli_fetch_array($pembeli)) {
                echo "<option value='$p[id_pembeli]'>$p[nama_pembeli]</option>";
              }
              ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Pilih Barang</label>
            <select name="id_barang" class="form-select" id="barangSelect" required>
              <option value="">-- Pilih Barang --</option>
              <?php
              $barang = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY nama_barang ASC");
              while($b = mysqli_fetch_array($barang)) {
                echo "<option value='$b[id_barang]' data-harga='$b[harga]' data-stok='$b[stok]'>$b[nama_barang] (Stok: $b[stok]) - Rp".number_format($b['harga'],0,',','.')."</option>";
              }
              ?>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Jumlah</label>
            <input type="number" name="jumlah" id="jumlah" class="form-control" min="1" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Total Harga (Otomatis)</label>
            <input type="text" id="total_display" class="form-control" readonly>
            <input type="hidden" name="total_harga" id="total_hidden">
          </div>
          <input type="hidden" name="tanggal" value="<?= $tanggal_hari_ini ?>">
        </div>
        <div class="modal-footer border-0">
          <button type="submit" name="tambah_transaksi" class="btn btn-primary w-100 rounded-pill">Simpan Transaksi</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Script Hitung Total Otomatis + Validasi Stok -->
<script>
  const barangSelect = document.getElementById('barangSelect');
  const jumlahInput = document.getElementById('jumlah');
  const totalDisplay = document.getElementById('total_display');
  const totalHidden = document.getElementById('total_hidden');

  function updateTotal() {
    const selectedOption = barangSelect.selectedOptions[0];
    const harga = parseFloat(selectedOption?.getAttribute('data-harga') || 0);
    const stok = parseInt(selectedOption?.getAttribute('data-stok') || 0);
    const jumlah = parseInt(jumlahInput.value) || 0;

    //  Jika jumlah lebih besar dari stok → pop-up warning SweetAlert
    if (jumlah > stok) {
      Swal.fire({
        icon: 'warning',
        title: 'Stok Tidak Cukup!',
        html: `
          <div style="font-size:14px;">
            Jumlah pembelian (${jumlah}) melebihi stok tersedia (${stok}).<br>
            Silakan kurangi jumlah pembelian.
          </div>
        `,
        confirmButtonText: 'Oke, kurangi jumlah',
        confirmButtonColor: '#1D35BD'
      }).then(() => {
        jumlahInput.value = stok;
        const total = harga * stok;
        totalDisplay.value = 'Rp' + total.toLocaleString('id-ID');
        totalHidden.value = total;
      });
      return;
    }

    // Update total harga otomatis
    const total = harga * jumlah;
    totalDisplay.value = jumlah > 0 ? 'Rp' + total.toLocaleString('id-ID') : '';
    totalHidden.value = total;
  }

  if (barangSelect && jumlahInput) {
    barangSelect.addEventListener('change', updateTotal);
    jumlahInput.addEventListener('input', updateTotal);
  }
</script>

<!-- DataTables: Aktifkan fitur pencarian, sorting, pagination, dan export -->
<script>
$(document).ready(function() {
  const table = $('#tabel-transaksi').DataTable({
    paging: true,              // aktifkan pagination
    searching: true,           // aktifkan kolom pencarian
    info: true,                // tampilkan info jumlah data
    ordering: true,            // aktifkan sorting
    pageLength: 5,             // tampilkan 5 data per halaman
    lengthChange: false,       // sembunyikan opsi jumlah baris
    dom: '<"d-flex justify-content-between align-items-center mb-3"fB>rtip',
    buttons: [
      {
        extend: 'excelHtml5',
        text: '<i class="bi bi-file-earmark-excel"></i> Excel',
        className: 'btn btn-success btn-sm rounded-pill me-2'
      },
      {
        extend: 'pdfHtml5',
        text: '<i class="bi bi-file-earmark-pdf"></i> PDF',
        className: 'btn btn-danger btn-sm rounded-pill'
      }
    ],
    language: {
      search: "🔍 Cari Transaksi:",
      zeroRecords: "Tidak ditemukan data yang cocok",
      info: "Menampilkan _START_ sampai _END_ dari _TOTAL_ transaksi",
      infoEmpty: "Tidak ada transaksi yang tersimpan",
      paginate: {
        next: "➡️",
        previous: "⬅️"
      }
    }
  });

  // pindahkan tombol export ke kanan atas
  table.buttons().container().appendTo('#exportButtons');
});
</script>


<style>
  table { border-collapse: separate !important; border-spacing: 0 4px; }
  tbody tr:hover { background-color: #f9faff !important; transition: 0.2s ease; }
  .btn-outline-primary, .btn-outline-danger { border-radius: 10px; padding: 4px 10px; font-size: 13px; }

  /* Style tambahan untuk search bar biar elegan */
  .dataTables_filter {
    float: left !important;
  }
  .dataTables_filter input {
    border-radius: 10px;
    border: 1px solid #ced4da;
    padding: 5px 10px;
    font-size: 14px;
    margin-left: 8px;
    width: 250px;
    outline: none;
    transition: 0.2s;
  }
  .dataTables_filter input:focus {
    border-color: #1D35BD;
    box-shadow: 0 0 4px rgba(29,53,189,0.3);
  }
</style>

