<?php include 'config/koneksi.php'; ?>
<div id="barang" class="section d-none">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center">
      <i class="bi bi-box-seam text-primary fs-4 me-2"></i>
      <h4 class="fw-bold text-primary mb-0">Data Barang</h4>
    </div>
    <button class="btn btn-primary px-3" data-bs-toggle="modal" data-bs-target="#modalTambahBarang">
      <i class="bi bi-plus-circle"></i> Tambah
    </button>
  </div>

  <!-- Card Table -->
  <div class="card p-4 shadow-sm border-0">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead class="table-light">
          <tr class="text-secondary">
            <th style="width:8%">No</th>
            <th style="width:12%">ID</th>
            <th style="width:35%">Nama Barang</th>
            <th style="width:20%">Harga</th>
            <th style="width:15%">Stok</th>
            <th style="width:20%">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          $data = mysqli_query($koneksi, "SELECT * FROM barang ORDER BY id_barang ASC");
          while($b = mysqli_fetch_array($data)) { ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $b['id_barang'] ?></td>
            <td class="fw-semibold"><?= strtoupper($b['nama_barang']) ?></td>
            <td>Rp<?= number_format($b['harga'],0,',','.') ?></td>
            <td><?= $b['stok'] ?></td>
            <td>
              <button class="btn btn-sm btn-outline-primary me-1" 
                      data-bs-toggle="modal" 
                      data-bs-target="#editBarang<?= $b['id_barang'] ?>">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger" 
                      onclick="hapusData('barang','<?= $b['id_barang'] ?>')">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>

          <!-- Modal Edit -->
          <div class="modal fade" id="editBarang<?= $b['id_barang'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content border-0 rounded-4 shadow-sm">
                <div class="modal-header border-0">
                  <h5 class="fw-semibold text-primary mb-0">Edit Barang</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="proses.php" method="POST">
                  <div class="modal-body">
                    <input type="hidden" name="id_barang" value="<?= $b['id_barang'] ?>">
                    <div class="mb-3">
                      <label class="form-label">Nama Barang</label>
                      <input type="text" name="nama_barang" value="<?= $b['nama_barang'] ?>" class="form-control" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Harga (Rp)</label>
                      <input type="number" name="harga" value="<?= $b['harga'] ?>" class="form-control" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Stok</label>
                      <input type="number" name="stok" value="<?= $b['stok'] ?>" class="form-control" required>
                    </div>
                  </div>
                  <div class="modal-footer border-0">
                    <button type="submit" name="edit_barang" class="btn btn-primary w-100">Simpan Perubahan</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Barang -->
<div class="modal fade" id="modalTambahBarang" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 rounded-4 shadow-sm">
      <div class="modal-header border-0">
        <h5 class="fw-semibold text-primary mb-0">Tambah Barang Baru</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <?php
        // ✅ AUTO ID BARANG BERURUT (BR001, BR002, dst)
        $query = mysqli_query($koneksi, "SELECT id_barang FROM barang ORDER BY id_barang DESC LIMIT 1");
        $data = mysqli_fetch_assoc($query);

        if ($data) {
          $lastId = $data['id_barang'];     // contoh: BR007
          $num = (int) substr($lastId, 2);  // ambil angka belakang -> 7
          $num++;                           // naik 1 -> 8
          $newId = "BR" . str_pad($num, 3, "0", STR_PAD_LEFT); // hasil: BR008
        } else {
          $newId = "BR001"; // jika tabel masih kosong
        }
      ?>

      <form action="proses.php" method="POST">
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">ID Barang</label>
            <input type="text" name="id_barang" class="form-control" 
                   value="<?= $newId ?>" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label">Nama Barang</label>
            <input type="text" name="nama_barang" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Harga (Rp)</label>
            <input type="number" name="harga" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Stok</label>
            <input type="number" name="stok" class="form-control" required>
          </div>
        </div>
        <div class="modal-footer border-0">
          <button type="submit" name="tambah_barang" class="btn btn-primary w-100">Tambah Barang</button>
        </div>
      </form>
    </div>
  </div>
</div>
