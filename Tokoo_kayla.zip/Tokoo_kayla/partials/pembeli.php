<?php include 'config/koneksi.php'; ?>
<div id="pembeli" class="section d-none">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center">
      <i class="bi bi-person-lines-fill text-primary fs-4 me-2"></i>
      <h4 class="fw-bold text-primary mb-0">Data Pembeli</h4>
    </div>
    <button class="btn btn-primary px-3" data-bs-toggle="modal" data-bs-target="#modalTambahPembeli">
      <i class="bi bi-plus-circle"></i> Tambah
    </button>
  </div>

  <!-- Card Table -->
  <div class="card p-4 shadow-sm border-0">
    <div class="table-responsive">
      <table class="table align-middle">
        <thead class="table-light">
          <tr class="text-secondary">
            <th style="width: 10%">ID</th>
            <th style="width: 35%">Nama Pembeli</th>
            <th style="width: 35%">Alamat</th>
            <th style="width: 20%">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $data = mysqli_query($koneksi, "SELECT * FROM pembeli ORDER BY CAST(SUBSTRING(id_pembeli, 3) AS UNSIGNED) ASC");
          while($p = mysqli_fetch_array($data)) { ?>
          <tr>
            <td><?= $p['id_pembeli'] ?></td>
            <td class="fw-semibold"><?= $p['nama_pembeli'] ?></td>
            <td><?= $p['alamat'] ?></td>
            <td>
              <button class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editPembeli<?= $p['id_pembeli'] ?>">
                <i class="bi bi-pencil"></i>
              </button>
              <button class="btn btn-sm btn-outline-danger" onclick="hapusData('pembeli','<?= $p['id_pembeli'] ?>')">
                <i class="bi bi-trash"></i>
              </button>
            </td>
          </tr>

          <!-- Modal Edit -->
          <div class="modal fade" id="editPembeli<?= $p['id_pembeli'] ?>" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
              <div class="modal-content border-0 rounded-4 shadow-sm">
                <div class="modal-header border-0">
                  <h5 class="fw-semibold text-primary mb-0">Edit Pembeli</h5>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form action="proses.php" method="POST">
                  <div class="modal-body">
                    <input type="hidden" name="id_pembeli" value="<?= $p['id_pembeli'] ?>">
                    <div class="mb-3">
                      <label class="form-label">Nama Pembeli</label>
                      <input type="text" name="nama_pembeli" value="<?= $p['nama_pembeli'] ?>" class="form-control" required>
                    </div>
                    <div class="mb-3">
                      <label class="form-label">Alamat</label>
                      <textarea name="alamat" class="form-control" required><?= $p['alamat'] ?></textarea>
                    </div>
                  </div>
                  <div class="modal-footer border-0">
                    <button type="submit" name="edit_pembeli" class="btn btn-primary w-100">Simpan Perubahan</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Modal Tambah Pembeli -->
<div class="modal fade" id="modalTambahPembeli" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 rounded-4 shadow-sm">
      <div class="modal-header border-0">
        <h5 class="fw-semibold text-primary mb-0">Tambah Pembeli Baru</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <?php
     // AUTO ID PEMBELI (berdasarkan angka terbesar agar selalu urut)
        $auto_pb = mysqli_query($koneksi, "
        SELECT MAX(CAST(SUBSTRING(id_pembeli, 3) AS UNSIGNED)) AS max_id 
        FROM pembeli
        ");
        $data_pb = mysqli_fetch_assoc($auto_pb);
        $max_id = $data_pb['max_id'] ?? 0;
        $next_id = $max_id + 1;
        $id_baru_pb = 'PB' . str_pad($next_id, 3, '0', STR_PAD_LEFT);

      ?>

      <form action="proses.php" method="POST">
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label">ID Pembeli</label>
            <input type="text" name="id_pembeli" class="form-control" value="<?= $id_baru_pb ?>" readonly>
          </div>
          <div class="mb-3">
            <label class="form-label">Nama Pembeli</label>
            <input type="text" name="nama_pembeli" class="form-control" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Alamat</label>
            <textarea name="alamat" class="form-control" required></textarea>
          </div>
        </div>
        <div class="modal-footer border-0">
          <button type="submit" name="tambah_pembeli" class="btn btn-primary w-100">Tambah Pembeli</button>
        </div>
      </form>
    </div>
  </div>
</div>

