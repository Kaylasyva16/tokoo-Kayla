<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'config/koneksi.php';

/* ==========================================================
   =============== CRUD BARANG ==============================
========================================================== */
if(isset($_POST['tambah_barang'])){
  $id = $_POST['id_barang'];
  $nama = strtoupper($_POST['nama_barang']);
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];

  $query = mysqli_query($koneksi, "INSERT INTO barang (id_barang, nama_barang, harga, stok) 
                                   VALUES('$id','$nama','$harga','$stok')");
  if($query){
    header("Location: index.php?success=barang_tambah");
  } else {
    header("Location: index.php?error=barang_gagal");
  }
  exit;
}

if(isset($_POST['edit_barang'])){
  $id = $_POST['id_barang'];
  $nama = strtoupper($_POST['nama_barang']);
  $harga = $_POST['harga'];
  $stok = $_POST['stok'];

  $query = mysqli_query($koneksi, "UPDATE barang SET nama_barang='$nama', harga='$harga', stok='$stok' WHERE id_barang='$id'");
  if($query){
    header("Location: index.php?success=barang_edit");
  } else {
    header("Location: index.php?error=barang_edit");
  }
  exit;
}

if(isset($_GET['hapus']) && $_GET['hapus'] == 'barang'){
  $id = $_GET['id'];
  $query = mysqli_query($koneksi, "DELETE FROM barang WHERE id_barang='$id'");
  if($query){
    header("Location: index.php?success=barang_hapus");
  } else {
    header("Location: index.php?error=barang_hapus");
  }
  exit;
}


/* ==========================================================
   =============== CRUD PEMBELI =============================
========================================================== */
if(isset($_POST['tambah_pembeli'])){
  $id = $_POST['id_pembeli'];
  $nama = $_POST['nama_pembeli'];
  $alamat = $_POST['alamat'];

  $query = mysqli_query($koneksi, "INSERT INTO pembeli (id_pembeli, nama_pembeli, alamat) 
                                   VALUES('$id','$nama','$alamat')");
  if($query){
    header("Location: index.php?success=pembeli_tambah");
  } else {
    header("Location: index.php?error=pembeli_gagal");
  }
  exit;
}

if(isset($_POST['edit_pembeli'])){
  $id = $_POST['id_pembeli'];
  $nama = $_POST['nama_pembeli'];
  $alamat = $_POST['alamat'];

  $query = mysqli_query($koneksi, "UPDATE pembeli SET nama_pembeli='$nama', alamat='$alamat' WHERE id_pembeli='$id'");
  if($query){
    header("Location: index.php?success=pembeli_edit");
  } else {
    header("Location: index.php?error=pembeli_edit");
  }
  exit;
}

if(isset($_GET['hapus']) && $_GET['hapus'] == 'pembeli'){
  $id = $_GET['id'];
  $query = mysqli_query($koneksi, "DELETE FROM pembeli WHERE id_pembeli='$id'");
  if($query){
    header("Location: index.php?success=pembeli_hapus");
  } else {
    header("Location: index.php?error=pembeli_hapus");
  }
  exit;
}


/* ==========================================================
   =============== CRUD TRANSAKSI + VALIDASI STOK ===========
========================================================== */
if(isset($_POST['tambah_transaksi'])){
  $id = $_POST['id_transaksi'];
  $id_pembeli = $_POST['id_pembeli'];
  $id_barang = $_POST['id_barang'];
  $jumlah = (int)$_POST['jumlah'];
  $total = $_POST['total_harga'];
  $tanggal = date('Y-m-d'); // otomatis tanggal hari ini

  // 🔹 Cek stok barang
  $cek = mysqli_query($koneksi, "SELECT stok FROM barang WHERE id_barang='$id_barang'");
  $stok_data = mysqli_fetch_assoc($cek);

  if(!$stok_data){
    header("Location: index.php?error=barang_tidak_ditemukan");
    exit;
  }

  $stok_sekarang = (int)$stok_data['stok'];

  // Jika jumlah yang diminta melebihi stok tersedia
  if($jumlah > $stok_sekarang){
    header("Location: index.php?error=stok_kurang");
    exit;
  }

  // Kurangi stok sesuai jumlah
  $stok_baru = $stok_sekarang - $jumlah;

  // Simpan transaksi
  $query = mysqli_query($koneksi, "
    INSERT INTO transaksi (id_transaksi, id_pembeli, id_barang, jumlah, total_harga, tanggal)
    VALUES('$id','$id_pembeli','$id_barang','$jumlah','$total','$tanggal')
  ");

  if($query){
    mysqli_query($koneksi, "UPDATE barang SET stok='$stok_baru' WHERE id_barang='$id_barang'");
    header("Location: index.php?success=transaksi_tambah");
  } else {
    header("Location: index.php?error=transaksi_gagal");
  }
  exit;
}



//  Edit Transaksi (stok dikembalikan & disesuaikan ulang)
if(isset($_POST['edit_transaksi'])){
  $id = $_POST['id_transaksi'];
  $id_pembeli = $_POST['id_pembeli'];
  $id_barang = $_POST['id_barang'];
  $jumlah_baru = $_POST['jumlah'];
  $total = $_POST['total_harga'];

  // ambil transaksi lama
  $lama = mysqli_query($koneksi, "SELECT * FROM transaksi WHERE id_transaksi='$id'");
  $old = mysqli_fetch_assoc($lama);
  $jumlah_lama = $old['jumlah'];
  $id_barang_lama = $old['id_barang'];

  // kembalikan stok lama
  mysqli_query($koneksi, "UPDATE barang SET stok = stok + $jumlah_lama WHERE id_barang='$id_barang_lama'");

  // kurangi stok baru
  $cek_baru = mysqli_query($koneksi, "SELECT stok FROM barang WHERE id_barang='$id_barang'");
  $stok_baru = mysqli_fetch_assoc($cek_baru)['stok'];

  if($stok_baru < $jumlah_baru){
    header("Location: index.php?error=stok_kurang");
    exit;
  }

  mysqli_query($koneksi, "UPDATE barang SET stok = stok - $jumlah_baru WHERE id_barang='$id_barang'");

  // update transaksi
  $query = mysqli_query($koneksi, "UPDATE transaksi 
                                   SET id_pembeli='$id_pembeli', id_barang='$id_barang', jumlah='$jumlah_baru', total_harga='$total' 
                                   WHERE id_transaksi='$id'");

  if($query){
    header("Location: index.php?success=transaksi_edit");
  } else {
    header("Location: index.php?error=transaksi_edit");
  }
  exit;
}


//  Hapus Transaksi (stok dikembalikan)
if(isset($_GET['hapus']) && $_GET['hapus'] == 'transaksi'){
  $id = $_GET['id'];
  $cek = mysqli_query($koneksi, "SELECT id_barang, jumlah FROM transaksi WHERE id_transaksi='$id'");
  $tr = mysqli_fetch_assoc($cek);

  if($tr){
    mysqli_query($koneksi, "UPDATE barang SET stok = stok + {$tr['jumlah']} WHERE id_barang='{$tr['id_barang']}'");
    mysqli_query($koneksi, "DELETE FROM transaksi WHERE id_transaksi='$id'");
    header("Location: index.php?success=transaksi_hapus");
  } else {
    header("Location: index.php?error=transaksi_hapus");
  }
  exit;
}
?>
