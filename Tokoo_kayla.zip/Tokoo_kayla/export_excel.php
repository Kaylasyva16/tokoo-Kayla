<?php
include 'config/koneksi.php';
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Transaksi_Toko_Kayla.xls");
?>

<table border="1" cellspacing="0" cellpadding="6">
  <thead style="background-color:#f2f2f2;">
    <tr>
      <th>ID Transaksi</th>
      <th>Nama Pembeli</th>
      <th>Nama Barang</th>
      <th>Jumlah</th>
      <th>Total Harga</th>
      <th>Tanggal</th>
    </tr>
  </thead>
  <tbody>
    <?php
    $data = mysqli_query($koneksi, 
      "SELECT t.*, p.nama_pembeli, b.nama_barang 
       FROM transaksi t 
       JOIN pembeli p ON t.id_pembeli=p.id_pembeli 
       JOIN barang b ON t.id_barang=b.id_barang 
       ORDER BY tanggal DESC");
    while($row = mysqli_fetch_array($data)){
      echo "<tr>
              <td>{$row['id_transaksi']}</td>
              <td>{$row['nama_pembeli']}</td>
              <td>{$row['nama_barang']}</td>
              <td>{$row['jumlah']}</td>
              <td>Rp".number_format($row['total_harga'],0,',','.')."</td>
              <td>{$row['tanggal']}</td>
            </tr>";
    }
    ?>
  </tbody>
</table>
