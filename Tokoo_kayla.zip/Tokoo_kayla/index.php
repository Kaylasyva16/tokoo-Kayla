<?php 
include 'config/koneksi.php';

// summary data
$total_barang = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM barang"));
$total_pembeli = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM pembeli"));
$total_transaksi = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM transaksi"));
$pendapatan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) as total FROM transaksi"))['total'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard Toko Kayla</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<style>
  :root {
    --primary: #1D35BD;
    --bg: #f6f8fc;
    --card: #ffffff;
    --gray: #7a7a7a;
  }
  body {
    font-family: "Poppins", sans-serif;
    background: var(--bg);
    color: #2b2b2b;
  }

  /* Sidebar */
  .sidebar {
    position: fixed;
    top: 0;
    left: 0;
    width: 230px;
    height: 100vh;
    background: var(--card);
    box-shadow: 2px 0 8px rgba(0,0,0,0.05);
    border-top-right-radius: 25px;
    border-bottom-right-radius: 25px;
    padding: 30px 0;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  .sidebar h4 {
    text-align: center;
    color: var(--primary);
    font-weight: 700;
  }
  .nav-links {
    display: flex;
    flex-direction: column;
    margin-top: 30px;
  }
  .nav-links a {
    padding: 12px 24px;
    color: var(--gray);
    font-weight: 500;
    text-decoration: none;
    display: flex;
    align-items: center;
    gap: 10px;
    transition: 0.3s ease;
  }
  .nav-links a:hover,
  .nav-links a.active {
    background: rgba(29,53,189,0.08);
    color: var(--primary);
    border-left: 4px solid var(--primary);
  }
  .footer {
    text-align: center;
    font-size: 12px;
    color: var(--gray);
  }

  /* Content */
  .content {
    margin-left: 250px;
    padding: 40px;
    transition: 0.3s ease;
  }
  .section {
    animation: fadeIn 0.4s ease;
  }
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }

  /* Dashboard Summary */
  .summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 20px;
  }
  .summary-card {
    background: var(--card);
    border-radius: 18px;
    padding: 25px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    border: 1px solid #f0f0f0;
    transition: 0.3s;
  }
  .summary-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.08);
  }
  .summary-card h6 {
    color: var(--gray);
    font-weight: 500;
  }
  .summary-card h3 {
    font-weight: 700;
  }

  /* Buttons */
  .btn-primary {
    background: var(--primary);
    border: none;
    border-radius: 10px;
  }
  .btn-primary:hover {
    background: #152396;
  }

  table {
    background: var(--card);
    border-radius: 15px;
    overflow: hidden;
  }
  thead {
    background: #f3f5ff;
  }
  tbody tr:hover {
    background-color: #fafbff;
  }
</style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
  <div>
    <h4>Kayla Store</h4>
    <div class="nav-links">
      <a href="#" class="active" onclick="showSection(this, 'dashboard')"><i class="bi bi-grid"></i> Dashboard</a>
      <a href="#" onclick="showSection(this, 'barang')"><i class="bi bi-box"></i> Barang</a>
      <a href="#" onclick="showSection(this, 'pembeli')"><i class="bi bi-person"></i> Pembeli</a>
      <a href="#" onclick="showSection(this, 'transaksi')"><i class="bi bi-receipt"></i> Transaksi</a>
    </div>
  </div>
  <div class="footer">© 2025 Kayla Syva</div>
</div>

<!-- Content -->
<div class="content">
  
<!-- Dashboard Section -->
<div id="dashboard" class="section">
  <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap">
    <div class="d-flex align-items-center">
      <i class="bi bi-bar-chart-line-fill text-primary fs-4 me-2"></i>
      <h4 class="fw-bold text-primary mb-0">Dashboard Ringkasan</h4>
    </div>

  </div>

  <?php
  // Total transaksi
  $total_transaksi = mysqli_num_rows(mysqli_query($koneksi, "SELECT * FROM transaksi"));

  // Total pendapatan
  $pendapatan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(total_harga) as total FROM transaksi"))['total'] ?? 0;

 // Barang terlaris (menampilkan semua barang dengan jumlah jual terbanyak)
$query_max = mysqli_query($koneksi, "
SELECT MAX(jumlah_terjual) AS max_jual FROM (
  SELECT COUNT(id_barang) AS jumlah_terjual
  FROM transaksi
  GROUP BY id_barang
) AS subquery
");
$max_jual = mysqli_fetch_assoc($query_max)['max_jual'] ?? 0;

$barang_terlaris_query = mysqli_query($koneksi, "
SELECT b.nama_barang, COUNT(t.id_barang) AS jumlah_terjual
FROM transaksi t
JOIN barang b ON t.id_barang = b.id_barang
GROUP BY b.id_barang
HAVING jumlah_terjual = '$max_jual'
");

$barang_terlaris_list = [];
while ($row = mysqli_fetch_assoc($barang_terlaris_query)) {
$barang_terlaris_list[] = $row['nama_barang'];
}
$nama_barang_terlaris = !empty($barang_terlaris_list) ? implode(', ', $barang_terlaris_list) : '-';
$jumlah_terjual = $max_jual;

  ?>

  <div class="summary">
    <div class="summary-card text-center">
      <i class="bi bi-receipt fs-2 text-primary mb-2"></i>
      <h6 class="text-secondary mb-1">Total Transaksi</h6>
      <h3 class="fw-bold"><?= $total_transaksi ?></h3>
    </div>

    <div class="summary-card text-center">
      <i class="bi bi-cash-stack fs-2 text-success mb-2"></i>
      <h6 class="text-secondary mb-1">Total Pendapatan</h6>
      <h3 class="fw-bold text-success">Rp<?= number_format($pendapatan, 0, ',', '.') ?></h3>
    </div>

    <div class="summary-card text-center">
      <i class="bi bi-box-seam fs-2 text-info mb-2"></i>
      <h6 class="text-secondary mb-1">Barang Terlaris</h6>
      <h5 class="fw-bold text-dark mb-0"><?= $nama_barang_terlaris ?></h5>
      <small class="text-muted"><?= $jumlah_terjual ?> transaksi</small>
    </div>
  </div>
</div>


  <!-- Include Section -->
  <?php include 'partials/barang.php'; ?>
  <?php include 'partials/pembeli.php'; ?>
  <?php include 'partials/transaksi.php'; ?>

</div>

<!-- JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showSection(el, id){
  // Hide all sections
  document.querySelectorAll('.section').forEach(s => s.classList.add('d-none'));
  
  // Show the selected one
  const target = document.getElementById(id);
  if (target) target.classList.remove('d-none');
  
  // Remove all active sidebar links
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active'));
  
  // Add active state to clicked link
  el.classList.add('active');
}
</script>
<script>
  const urlParams = new URLSearchParams(window.location.search);
  const success = urlParams.get('success');
  const error = urlParams.get('error');

  if(success === 'barang_tambah'){
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Barang berhasil ditambahkan 🎉',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if(error === 'barang_gagal'){
    Swal.fire({
      icon: 'error',
      title: 'Gagal!',
      text: 'Barang gagal ditambahkan 😢',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  // ✅ Tambahan baru di bawah ini
  if(success === 'barang_edit'){
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Perubahan berhasil disimpan ✏️',
      showConfirmButton: false,
      timer: 1800
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if(success === 'barang_hapus'){
    Swal.fire({
      icon: 'success',
      title: 'Dihapus!',
      text: 'Barang berhasil dihapus 🗑️',
      showConfirmButton: false,
      timer: 1800
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }
    // ✅ SweetAlert untuk PEMBELI
    if(success === 'pembeli_tambah'){
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Pembeli baru berhasil ditambahkan 🎉',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if(success === 'pembeli_edit'){
    Swal.fire({
      icon: 'success',
      title: 'Berhasil!',
      text: 'Data pembeli berhasil diperbarui ✏️',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if(success === 'pembeli_hapus'){
    Swal.fire({
      icon: 'success',
      title: 'Dihapus!',
      text: 'Data pembeli berhasil dihapus 🗑️',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  if(error === 'pembeli_gagal'){
    Swal.fire({
      icon: 'error',
      title: 'Gagal!',
      text: 'Terjadi kesalahan saat menambahkan atau mengedit data pembeli 😢',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

</script>
<script>
  // 🔥 Konfirmasi hapus data
  function hapusData(tabel, id){
    Swal.fire({
      title: 'Yakin ingin menghapus?',
      text: 'Data akan dihapus secara permanen!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#6c757d',
      confirmButtonText: 'Ya, hapus',
      cancelButtonText: 'Batal'
    }).then((result) => {
      if (result.isConfirmed) {
        // Redirect ke proses hapus sesuai tabel dan id
        window.location = `proses.php?hapus=${tabel}&id=${id}`;
      }
    });
  }

</script>
<script>
  const urlParams = new URLSearchParams(window.location.search);
  const success = urlParams.get('success');
  const error = urlParams.get('error');

  // ==================== SWEETALERT TRANSAKSI ====================

  // ✅ Tambah Transaksi Berhasil
  if (success === 'transaksi_tambah') {
    Swal.fire({
      icon: 'success',
      title: 'Transaksi Berhasil!',
      text: 'Transaksi baru berhasil ditambahkan 💰',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  // ❌ Tambah Transaksi Gagal
  if (error === 'transaksi_gagal') {
    Swal.fire({
      icon: 'error',
      title: 'Gagal Menambahkan!',
      text: 'Terjadi kesalahan saat menambah transaksi 😢',
      showConfirmButton: false,
      timer: 2000
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  // ✅ Edit Transaksi
  if (success === 'transaksi_edit') {
    Swal.fire({
      icon: 'success',
      title: 'Perubahan Disimpan!',
      text: 'Data transaksi berhasil diperbarui ✏️',
      showConfirmButton: false,
      timer: 1800
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }

  // ✅ Hapus Transaksi
  if (success === 'transaksi_hapus') {
    Swal.fire({
      icon: 'success',
      title: 'Data Dihapus!',
      text: 'Transaksi berhasil dihapus 🗑️',
      showConfirmButton: false,
      timer: 1800
    });
    window.history.replaceState({}, document.title, window.location.pathname);
  }
</script>

<!-- ✅ jQuery dan DataTables + Buttons (agar Excel & PDF muncul) -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.bootstrap5.min.css">
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.bootstrap5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.2.7/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>

</body>
</html>
