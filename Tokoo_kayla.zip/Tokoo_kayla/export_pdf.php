<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('fpdf/fpdf.php');
include 'config/koneksi.php';

class PDF extends FPDF {
  function Header(){
    $this->SetFont('Arial','B',14);
    $this->Cell(0,10,'Laporan Transaksi Toko Kayla',0,1,'C');
    $this->Ln(5);
    $this->SetFont('Arial','B',10);
    $this->Cell(20,10,'ID',1,0,'C');
    $this->Cell(40,10,'Pembeli',1,0,'C');
    $this->Cell(40,10,'Barang',1,0,'C');
    $this->Cell(20,10,'Jumlah',1,0,'C');
    $this->Cell(35,10,'Total Harga',1,0,'C');
    $this->Cell(30,10,'Tanggal',1,1,'C');
  }

  function Footer(){
    $this->SetY(-15);
    $this->SetFont('Arial','I',8);
    $this->Cell(0,10,'Generated on '.date('d-m-Y'),0,0,'C');
  }
}

$pdf = new PDF();
$pdf->AddPage();
$pdf->SetFont('Arial','',10);

$data = mysqli_query($koneksi, 
  "SELECT t.*, p.nama_pembeli, b.nama_barang 
   FROM transaksi t 
   JOIN pembeli p ON t.id_pembeli=p.id_pembeli 
   JOIN barang b ON t.id_barang=b.id_barang 
   ORDER BY tanggal DESC");

while($row = mysqli_fetch_array($data)){
  $pdf->Cell(20,10,$row['id_transaksi'],1,0,'C');
  $pdf->Cell(40,10,$row['nama_pembeli'],1,0,'C');
  $pdf->Cell(40,10,$row['nama_barang'],1,0,'C');
  $pdf->Cell(20,10,$row['jumlah'],1,0,'C');
  $pdf->Cell(35,10,'Rp'.number_format($row['total_harga'],0,',','.'),1,0,'R');
  $pdf->Cell(30,10,$row['tanggal'],1,1,'C');
}

$pdf->Output('D','Laporan_Transaksi_Toko_Kayla.pdf');
?>
